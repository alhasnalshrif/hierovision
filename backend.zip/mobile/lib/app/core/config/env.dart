class Environment {
  // This should be loaded from secure storage in production
  // For development purposes, we'll define it here
  static const String geminiApiKey = 'AIzaSyB15mpnjP6CHAEyP2WCDmiDDhTh_IrPF40';
}
