﻿import 'package:get/get.dart';

class BookmarksController extends GetxController {
  final RxBool isLoading = false.obs;
  
  @override
  void onInit() {
    super.onInit();
  }
}
