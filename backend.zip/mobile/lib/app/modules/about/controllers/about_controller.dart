﻿import 'package:get/get.dart';

class AboutController extends GetxController {
  final RxBool isLoading = false.obs;
  
  @override
  void onInit() {
    super.onInit();
  }
}
