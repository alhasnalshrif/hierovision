# Import models for convenience
from app.models.user import User
from app.models.scan import Scan
from app.models.token import BlacklistedToken
